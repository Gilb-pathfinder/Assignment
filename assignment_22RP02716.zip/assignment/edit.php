<?php
include 'db.php';
include 'auth.php';

$id = $_GET['id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST'){

    $reg_no = $_POST['reg_no'];
    $name = $_POST['names'];
    $email = $_POST['email'];
    $class = $_POST['class'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $address = $_POST['address'];

    $sql = "UPDATE students SET Reg_Number = '$reg_no', StudentNames = '$name', Email = '$email', Classes = '$class', Gender = '$gender', Age = '$age', Addresses = '$address' WHERE Id = '$id'";
$result = mysqli_query($conn,$sql);
if ($result === TRUE){
header("location: home.php");
}else{

    echo "Error:" . $sql . "<br>" . $conn->error;
}
}else {

    $query = "SELECT * FROM students WHERE Id = '$id'";
    $result = mysqli_query($conn,$query);
    $row = $result->fetch_assoc();

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Student_Info</title>
    <style>
    
    body{

       background-color: aquamarine;
       font-family: 'poppins';

    }
    .edit_info{
           margin: auto;
           margin-top: 50px;
           background-color: whitesmoke;
           width: 300px;
           height: 490px;
           border-radius: 5px;
           box-shadow: 5px 5px 20px darkcyan;
           padding: 30px;
           position: relative;
           right: 520px;
       }
       a{
           text-decoration: none;
           margin-left: 10px;
       }
input[type="text"],input[type="email"]{

width: 95%;
border: none;
border-radius: 10px;
font-family: 'poppins';
padding: 5px;
color: Black;
margin-top: 10px;
border: 1px black solid;
font-weight: 14px;
font-size: 14px;
}
input[type="radio"]{

padding: 30px;
}
input[type="password"],input[type="date"]{
margin: 8px 8px 8px 0px;
width: 95%;
border: none;
margin-top: 15px;
border-radius: 10px;
padding: 5px;
color: Black;
font-family: 'poppins';
border: 1px black solid;
font-weight: 14px;
font-size: 14px;
}
input,select{
    box-sizing: content-box;
    height: 40px;
}
p{
  color: yellowgreen;
  position: relative;
  left: 5px;
  top: 10px;
}
label{
   color: gray;
}
h2{
   color: blue;
   font-size: 32px;
   position: relative;
   bottom: 40px;
   left: 15px;
}
input{
   height: 35px;
  
}
form{
    position: relative;
    bottom: 50px;
}
input[type="submit"]{

width: 96%;
height: 40px;
background-color:blue;
border: none;
border-radius: 10px;
margin-top: 15px;
padding: 5px;
color: white;
font-family: 'poppins';
font-weight: 14px;
font-size: 16px;
text-align: center
}
.back{
    background-color: rgb(247, 118, 13);
    padding: 10px;
    border-radius: 5px;
    position: relative;
    top: 20px;
}
</style>
</head>
<body>
<a href="home.php" class="back">Back</b></a>
    <div class="edit_info">
    <h2>Edit Students Info</h2>
    <form action="edit.php?id=<?php echo $id; ?>" method="POST">
  
  <input type="text" name="reg_no" placeholder="Reg_Number" value="<?php echo $row['Reg_Number']; ?>"required><br>
  <input type="text" name="names" placeholder="Student_Names"value="<?php echo $row['StudentNames']; ?>" required><br>
  <input type="email" name="email" placeholder="Email" value="<?php echo $row['Email']; ?>"required><br>
  <input type="text" name="class" placeholder="class" value="<?php echo $row['Classes']; ?>"required><br>
  <input type="radio" name="gender" value="M">Male
  <input type="radio" name="gender" value="F">Female<br>
  <input type="text" name="age" placeholder="Your Age" value="<?php echo $row['Age']; ?>"required><br>
  <input type="text" name="address" placeholder="Your Address" value="<?php echo $row['Addresses']; ?>"required><br>
  <input type="submit" name="save" value="Save Changes">

  </form>
    </div>

</body>
</html>