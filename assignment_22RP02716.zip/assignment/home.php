<?php

include 'db.php';
include 'auth.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>
    
<div class="form">

</div>
<div class="result">

</div>
</body>
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard-Student Management System</title>
    <style>
    
    body{

       background-color: aquamarine;
       font-family: 'poppins';

    }
    .add_info{
           margin: auto;
           margin-top: 50px;
           background-color: whitesmoke;
           width: 250px;
           height: 460px;
           border-radius: 5px;
           box-shadow: 5px 5px 20px darkcyan;
           padding: 30px;
           position: relative;
           right: 520px;
       }
       a{
           text-decoration: none;
           margin-left: 10px;
       }
input[type="text"],input[type="email"]{

width: 95%;
border: none;
border-radius: 10px;
font-family: 'poppins';
padding: 4px;
color: Black;
margin-top: 10px;
border: 1px black solid;
font-weight: 14px;
font-size: 12px;
}
input[type="password"],input[type="date"]{
margin: 8px 8px 8px 0px;
width: 95%;
border: none;
margin-top: 15px;
border-radius: 10px;
padding: 4px;
color: Black;
font-family: 'poppins';
border: 1px black solid;
font-weight: 12px;
font-size: 14px;
}
input,select{
    box-sizing: content-box;
    height: 35px;
}
p{
  color: yellowgreen;
  position: relative;
  left: 5px;
  top: 10px;
}
label{
   position: relative;
   bottom: 12px;
}
h1{
   color: blue;
   font-size: 48px;
}
h2{
   color: blue;
   font-size: 28px;
   position: relative;
   bottom: 35px;
}
.h2{
   color: blue;
   font-size: 24px;
   position: relative;
   bottom: 40px;
   left: 15px;
}
form{
    position: relative;
    bottom: 50px;
}
input{
   height: 35px;
  
}
input[type="submit"]{

width: 96%;
height: 40px;
background-color:blue;
border: none;
border-radius: 10px;
margin-top: 15px;
padding: 4px;
color: white;
font-family: 'poppins';
font-weight: 14px;
font-size: 16px;
text-align: center
}
input[type="radio"]{

padding: 30px;
}
      .display{
        bottom: 470px;
        left: 300px;
        position: relative;
        margin: auto;
        background-color: lightcyan;
        padding: 20px;
        width: 1200px;
        height: auto;
        box-shadow: 3px 3px 14px darkcyan;
        border-radius: 3px;
      }
      a{
        text-decoration: none;
        color: white;
      }
      .logout{
        font-family: 'poppins';
        padding: 8px;
        background-color: red;
        position: fixed;
        left: 1200px;
        top: 20px;
        border: none;
        border-radius: 5px;
        z-index: 1000;

        

      }
      table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: none;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #d3e8f9;
        }
        tr:nth-child(odd) {
            background-color: #f5e0e5;
        }
        tr:hover {
            background-color: #ddd;
        }

        .delete{
          background-color: #DC143C;
          /* background: linear-gradient(to right, #B71C1C, #F44336); */
          border: none;
          color: white;
          padding: 8px;
          font-size: medium;
          border-radius: 6px;
        }
        .edit{
          background-color: #adb0ad;

          border: none;
          color: white;
          padding: 8px;
          font-size: medium;
          border-radius: 6px;
        }
    </style>
   </style>
</head>
<body>
<h1>DASHBOARD</h1>
  <h2>Welcome, <?php echo $_SESSION["UserName"];?></b></h2>
<a href="logout.php" class="logout">Logout <b><?php echo $_SESSION["UserName"];?></b></a>
   <div class="add_info">
   <h2 class="h2">Add new Student</h2>
   <form action="add.php" method="POST">
  
    <input type="text" name="reg_no" placeholder="Reg_Number" required><br>
    <input type="text" name="names" placeholder="Student_Names" required><br>
    <input type="email" name="email" placeholder="Email" required><br>
    <input type="text" name="class" placeholder="class" required><br>
    <span></span><input type="radio" name="gender" value="M"><label>Male</label>
    <input type="radio" name="gender" value="F"><label>Female</label><br>
    <input type="text" name="age" placeholder="Your Age" required><br>
    <input type="text" name="address" placeholder="Your Address" required><br>
    <input type="submit" name="save" value="Submit">

    </form>
    </div>
    <div class="display">
<table>
    <tr>
        <th>Id</th>
        <th>Reg_Number</th>
        <th>Student_Names</th>
        <th>Email</th>
        <th>Class</th>
        <th>Gender</th>
        <th>Age</th>
        <th>Address</th>
        <th>Action</th>
    </tr>
       <?php
        $sql = "SELECT * FROM students";
        $result = mysqli_query($conn,$sql);
        if($result && mysqli_num_rows($result)>0){
            while($row = $result->fetch_assoc()):
        ?>
        <tr>
                <td><?php echo $row['Id'];?></td>
                <td><?php echo $row['Reg_Number'];?> </td>
                <td><?php echo $row['StudentNames'];?></td>
                <td><?php echo $row['Email'];?></td>
                <td><?php echo $row['Classes'];?> </td>
                <td><?php echo $row['Gender'];?> </td>
                <td><?php echo $row['Age'];?></td>
                <td><?php echo $row['Addresses'];?></td>
                <td>
                <a href="edit.php?id=<?php echo $row['Id']; ?> " class="edit">Edit</a>
                <a href="delete.php?id=<?php echo $row['Id']; ?>" class="delete">Delete</a>
                </td>
                </tr>
            <?php endwhile; }
            else {
                echo "<tr><td colspan='5' >No Task found! </td></tr>";
            }
            ?>
            </table>
            </div>
</body>
</html>