<?php
include 'db.php';
include 'auth.php';

$id = $_GET['id'];
$sql = "DELETE FROM students WHERE Id ='$id'";
$result = mysqli_query($conn,$sql);
if ($result === TRUE){
header("location: home.php");
}else{

    echo "Error:" . $sql . "<br>" . $conn->error;
}
?>