<?php
session_start();

$conn = mysqli_connect("localhost", "root", "", "students-mgt");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$errors = [];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save'])) {

    $name = htmlspecialchars(trim($_POST['name']));
    $password = htmlspecialchars(trim($_POST['password']));

    if (empty($name)) {
        $errors[] = "Username or Email is required.";
    }

    if (empty($password)) {
        $errors[] = "Password is required.";
    }

    if (empty($errors)) {
        $sql = "SELECT id, username, password FROM users WHERE username = '$name'";
        $result = mysqli_query($conn, $sql);

        if ($result && mysqli_num_rows($result) === 1) {
            $row = mysqli_fetch_assoc($result);

            if ($row['username'] === $name &&  $row['password'] === $password) {
                $_SESSION['UserName'] = $row['username'];
                $_SESSION['id'] = $row['id'];
                header("Location: home.php");
                exit();
            } else {
                header("Location: login.php?error=Incorrect Username or Password");
                exit();
            }
        } else {
            header("Location: login.php?error=Incorrect Username or Password");
            exit();
        }
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
    
     body{

        background-color: aquamarine;
        font-family: 'poppins';

     }
     .login_container{
            margin: auto;
            margin-top: 100px;
            background-color: whitesmoke;
            width: 300px;
            height: 330px;
            border-radius: 5px;
            box-shadow: 5px 5px 20px darkcyan;
            padding: 30px;
            position: relative;
            left: 450px;

        }
        a{
            text-decoration: none;
            margin-left: 10px;
        }
input[type="text"]{

width: 95%;
border: none;
border-radius: 10px;
font-family: 'poppins';
padding: 5px;
color: Black;
margin-top: 10px;
border: 1px black solid;
font-weight: 14px;
font-size: 14px;
}
input[type="password"]{
margin: 8px 8px 8px 0px;
width: 95%;
border: none;
margin-top: 15px;
border-radius: 10px;
padding: 5px;
color: Black;
font-family: 'poppins';
border: 1px black solid;
font-weight: 14px;
font-size: 14px;
}
p{
   color: yellowgreen;
   position: relative;
   left: 20px;
   top: 10px;
}
label{
    color: gray;
}
h2{
    color: blue;
    position: relative;
    left: 25px;
    font-size: 24px;
}
input{
    height: 35px;
   
}
input[type="submit"]{

width: 98%;
height: 47px;
background-color:blue;
border: none;
border-radius: 10px;
margin-top: 15px;
padding: 10px;
color: white;
font-family: 'poppins';
font-weight: 14px;
font-size: 16px;
text-align: center
}
.error{
    color: red;
}
    </style>
</head>
<body>

<div class="login_container">
    <h2>Login-SDMS APP</h2>
    <form action="" method="POST">
        <input type="text" name="name" placeholder="Username or Email" value="<?php echo isset($name) ? $name : ''; ?>">
        <input type="password" name="password" placeholder="Password">
        <input type="submit" name="save" value="Login">

        <p>Don't have an account? <a href="#">Sign-UP</a></p>
    </form>

    <?php
    if (!empty($errors)) {
        echo '<ul>';
        foreach ($errors as $error) {
            echo '<li>' . $error . '</li>';
        }
        echo '</ul>';
    }

    if (isset($_GET['error'])) {
        echo "<p class='error'>" . htmlspecialchars($_GET['error']) . "</p>";
    }
    ?>
</div>

</body>
</html>
