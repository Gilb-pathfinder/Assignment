<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management System</title>
</head>
<body>

<h1>WELCOME TO STUDENTS MANAGEMENT SYSTEM</h1>
<div class="container">
    <p>This is the Students Management System that manage all of our Students 
        registered in all intake we have ever taken </p>
</div>
<div class="links">
<button class="signup"><a href="signup.php">SignUp</a></button>
<button class="login"><a href="login.php">Login</a></button>
</div>
</body>
</html>