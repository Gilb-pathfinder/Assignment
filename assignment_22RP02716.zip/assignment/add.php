<?php
include 'db.php';
include 'auth.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST'){

$reg_no = $_POST['reg_no'];
$name = $_POST['names'];
$email = $_POST['email'];
$class = $_POST['class'];
$gender = $_POST['gender'];
$age = $_POST['age'];
$address = $_POST['address'];

$sql = "INSERT INTO students (Reg_Number,StudentNames,Email,Classes,Gender,Age,Addresses) VALUES ('$reg_no','$name','$email','$class','$gender','$age','$address')";
$result = mysqli_query($conn,$sql);
if ($result === TRUE){
header("location: home.php");
}else{

    echo "Error:" . $sql . "<br>" . $conn->error;
}

}
?>