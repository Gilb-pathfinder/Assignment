<?php
$conn = mysqli_connect("localhost","root","","students-mgt");

if (!$conn){
 
    die("Connection failed." . mysqli_connect_error());
}
?>